# Пошаговая инструкция по запуску сборки.

## 1 Убедитесь что у вас установлен Node js (проверить можно командой: node --version )

    Если его нет, то установить можно по ссылке: https://nodejs.org/en/

## 2 Установите gulp глобально на Ваш ПК:

    npm install --global gulp-cli

    Ссылка на инстуркцию по установке Gulp
    https://gulpjs.com/docs/en/getting-started/quick-start

## 3 Установите все зависимости комадой:

    npm install

## 4 Запустите Сборку

    gulp
